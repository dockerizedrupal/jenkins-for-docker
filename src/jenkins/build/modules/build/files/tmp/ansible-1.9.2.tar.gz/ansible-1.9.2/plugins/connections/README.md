Connections are also pluggable, see lib/ansible/runner/connection_plugins/ for the ones that ship with ansible.

When non-core alternatives are available, they can be shared here.

